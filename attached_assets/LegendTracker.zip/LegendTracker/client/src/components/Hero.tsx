import { cocktailServiceImages, brandLogos } from "@/lib/assets";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";

export default function Hero() {
  return (
    <section 
      className="relative h-screen bg-cover bg-center" 
      style={{ backgroundImage: `url(${cocktailServiceImages[0]})` }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-60"></div>
      <div className="relative container mx-auto px-4 h-full flex flex-col justify-center items-center text-center">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-white mb-6">
          House of <span className="text-secondary">Legends</span>
        </h1>
        <p className="text-xl md:text-2xl text-white mb-10 max-w-3xl">
          Namibia's premier cocktail and hospitality collective, bringing exceptional experiences through our three specialized brands.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl">
          {/* House of Legends Card */}
          <div className="bg-white bg-opacity-10 backdrop-blur-sm p-6 rounded-lg border border-white border-opacity-20 transform hover:scale-105 transition-transform">
            <img src={brandLogos.houseOfLegends} alt="House of Legends Logo" className="h-12 mx-auto mb-4" />
            <h3 className="text-xl font-display font-semibold text-secondary mb-2">House of Legends</h3>
            <p className="text-white text-sm">Premium cocktail experiences and events</p>
          </div>
          
          {/* Legends of Cocktails Card */}
          <div className="bg-white bg-opacity-10 backdrop-blur-sm p-6 rounded-lg border border-white border-opacity-20 transform hover:scale-105 transition-transform">
            <img src={brandLogos.legendsOfCocktails} alt="Legends of Cocktails Logo" className="h-12 mx-auto mb-4" />
            <h3 className="text-xl font-display font-semibold text-secondary mb-2">Legends of Cocktails</h3>
            <p className="text-white text-sm">Mobile bar services and hospitality staffing</p>
          </div>
          
          {/* Namibian Bar Masters Card */}
          <div className="bg-white bg-opacity-10 backdrop-blur-sm p-6 rounded-lg border border-white border-opacity-20 transform hover:scale-105 transition-transform">
            <img src={brandLogos.namibianBarMasters} alt="Namibian Bar Masters Logo" className="h-12 mx-auto mb-4" />
            <h3 className="text-xl font-display font-semibold text-secondary mb-2">Namibian Bar Masters</h3>
            <p className="text-white text-sm">Professional bartender training and certification</p>
          </div>
        </div>
        
        <a href="#services" className="mt-12 text-white group flex flex-col items-center">
          <span className="block text-sm font-medium mb-2">Discover Our Services</span>
          <Button variant="ghost" size="icon" className="text-white animate-bounce">
            <ChevronDown className="h-6 w-6" />
          </Button>
        </a>
      </div>
    </section>
  );
}
