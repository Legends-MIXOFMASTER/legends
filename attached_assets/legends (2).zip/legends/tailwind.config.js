
module.exports = {
  content: ['./**/*.{html,js}'],
  theme: {
    extend: {
      colors: {
        gold: '#C9A850',
        navy: '#0E0E1B',
        offwhite: '#F5F5F5'
      },
      fontFamily: {
        'playfair': ['"Playfair Display"', 'serif'],
        'montserrat': ['Montserrat', 'sans-serif']
      }
    }
  },
  plugins: []
}
