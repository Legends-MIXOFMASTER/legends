
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.createElement('nav');
  nav.className = 'bg-navy text-white sticky-nav';
  nav.innerHTML = `
    <div class="container mx-auto px-4 py-4">
      <div class="flex justify-between items-center">
        <a href="/" class="text-2xl font-playfair text-gold">House of Legends</a>
        
        <div class="hidden md:flex space-x-6">
          <a href="/" class="hover:text-gold transition">Home</a>
          <a href="/gallery.html" class="hover:text-gold transition">Gallery</a>
          <a href="/book-event.html" class="hover:text-gold transition">Book Event</a>
          <a href="/bookings.html" class="auth-required hidden hover:text-gold transition">My Bookings</a>
          <a href="/login.html" class="auth-hide hover:text-gold transition">Login</a>
          <a href="/register.html" class="auth-hide hover:text-gold transition">Register</a>
          <a href="#" onclick="logout()" class="auth-required hidden hover:text-gold transition">Logout</a>
        </div>

        <button class="md:hidden mobile-menu-btn">
          <i class="fas fa-bars text-2xl"></i>
        </button>
      </div>

      <div class="mobile-menu hidden md:hidden mt-4 space-y-4">
        <a href="/" class="block hover:text-gold transition">Home</a>
        <a href="/gallery.html" class="block hover:text-gold transition">Gallery</a>
        <a href="/book-event.html" class="block hover:text-gold transition">Book Event</a>
        <a href="/bookings.html" class="auth-required hidden block hover:text-gold transition">My Bookings</a>
        <a href="/login.html" class="auth-hide block hover:text-gold transition">Login</a>
        <a href="/register.html" class="auth-hide block hover:text-gold transition">Register</a>
        <a href="#" onclick="logout()" class="auth-required hidden block hover:text-gold transition">Logout</a>
      </div>
    </div>
  `;

  // Insert navigation at the start of the body
  document.body.insertBefore(nav, document.body.firstChild);

  // Handle mobile menu
  const mobileMenuBtn = nav.querySelector('.mobile-menu-btn');
  const mobileMenu = nav.querySelector('.mobile-menu');

  mobileMenuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
  });

  // Handle authentication state
  const token = localStorage.getItem('token');
  if (token) {
    nav.querySelectorAll('.auth-required').forEach(el => el.classList.remove('hidden'));
    nav.querySelectorAll('.auth-hide').forEach(el => el.classList.add('hidden'));
  }

  // Handle scroll effect
  window.addEventListener('scroll', () => {
    if (window.scrollY > 0) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  });
});
