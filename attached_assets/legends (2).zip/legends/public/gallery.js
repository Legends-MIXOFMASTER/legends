
let images = [];
const isAdmin = () => localStorage.getItem('token') !== null;

document.addEventListener('DOMContentLoaded', () => {
    if (isAdmin()) {
        document.getElementById('adminControls').classList.remove('hidden');
    }
    loadGallery();
    setupEventListeners();
});

function setupEventListeners() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const toggleUpload = document.getElementById('toggleUpload');

    toggleUpload.addEventListener('click', () => {
        document.getElementById('uploadUI').classList.toggle('hidden');
    });

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('bg-gray-100');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('bg-gray-100');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('bg-gray-100');
        handleFiles(e.dataTransfer.files);
    });

    fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });
}

function handleFiles(files) {
    Array.from(files).forEach(file => {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                images.push(e.target.result);
                updateGallery();
                updatePreview();
            };
            reader.readAsDataURL(file);
        }
    });
}

function updatePreview() {
    const preview = document.getElementById('preview');
    preview.innerHTML = '';
    
    images.slice(-4).forEach(src => {
        const img = document.createElement('img');
        img.src = src;
        img.className = 'w-full h-32 object-cover rounded';
        preview.appendChild(img);
    });
}

function updateGallery() {
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = images.map(src => `
        <div class="relative group cursor-pointer" onclick="openModal('${src}')">
            <img src="${src}" alt="" class="w-full h-64 object-cover rounded transition-transform duration-300 group-hover:scale-105">
            <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded flex items-center justify-center">
                <i class="fas fa-search text-white text-2xl"></i>
            </div>
        </div>
    `).join('');
}

function openModal(src) {
    const modal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    modal.classList.remove('hidden');
    modalImage.src = src;
}

function closeModal() {
    const modal = document.getElementById('imageModal');
    modal.classList.add('hidden');
}

function loadGallery() {
    // In a real application, this would fetch images from a server
    // For now, we'll use placeholder images
    images = [
        'https://placehold.co/600x400/gold/white?text=Event+1',
        'https://placehold.co/600x400/gold/white?text=Event+2',
        'https://placehold.co/600x400/gold/white?text=Event+3',
    ];
    updateGallery();
}
