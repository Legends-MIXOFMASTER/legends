
async function login(email, password) {
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('token', data.token);
            window.location.href = '/';
        } else {
            throw new Error('Login failed');
        }
    } catch (error) {
        alert('Login failed. Please check your credentials.');
    }
}

async function register(name, email, password) {
    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, password })
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('token', data.token);
            window.location.href = '/';
        } else {
            throw new Error('Registration failed');
        }
    } catch (error) {
        alert('Registration failed. Please try again.');
    }
}

function logout() {
    localStorage.removeItem('token');
    window.location.href = '/login.html';
}

// Check authentication status
function checkAuth() {
    const token = localStorage.getItem('token');
    const protectedPages = ['/bookings.html', '/book-event.html'];
    const currentPage = window.location.pathname;

    if (!token && protectedPages.includes(currentPage)) {
        window.location.href = '/login.html';
    }
}

// Run auth check when page loads
document.addEventListener('DOMContentLoaded', checkAuth);
